# Hyprial compatibility distribution

This is a modified Apache-2.0 distribution of Yan-Zero/dsh-codex v0.2.7.
See UPSTREAM.json for the exact upstream commit and LICENSE for the license.
Source and release artifacts are maintained together in the GUI repository at
`vendor/dsh-codex` and `packages/dsh-codex`; this package is not published to npm.

Changes in 0.2.7-hyprial.3:

- Mark DSH/React peers as optional for the package manager: the DSH profile
  loader supplies these modules from the host. They remain required at runtime;
  GUI installation still validates the composed host configuration. Locally
  installed incompatible peer versions are not exempted from version checks.
- GUI installation acknowledges only node-domexception@1.0.0's deprecation.
  On the supported Node runtime that module exports the native DOMException;
  its legacy fallback is not used. The package remains an upstream indirect
  dependency; this is a narrow deprecation exception, not dependency removal.

Changes in 0.2.7-hyprial.2:

- Size the proxy selector columns from the available options, removing the empty
  third segment while keeping both choices equal at narrow and wide widths.

Changes in 0.2.7-hyprial.1:

- Pin pi-ai 0.84.4 as a private runtime dependency, independent of DSH's pi-ai.
- Run OAuth login/refresh, model SSE/WebSocket and auxiliary Codex HTTP in a
  private child process. Keep DSH sessions, tool execution, credential persistence
  and the cross-process refresh lock in the host.
- Legacy `global` proxy settings now mean isolated `scoped`. `off` means direct
  Codex networking. The host's global dispatcher/fetch are never patched.
- Proxy only HTTPS auth.openai.com OAuth/device-code endpoints and chatgpt.com/backend-api/ requests.
  Redirects are rejected. Remote images fetched by read_image remain on its
  existing direct, SSRF-checked HTTP path.
- Forward interactive login prompts and cancellation over IPC. Model payload
  callbacks and streamed data use acknowledged IPC frames. The host model event
  buffer is capped at 64 MiB to fail stalled consumers without unbounded growth. Worker
  exit rejects pending requests; requests are never silently replayed.
- Preserve one worker (including WebSocket connection caching) per active proxy
  configuration. An old configuration drains existing work before retiring.
  The worker exits on host disconnect. Idle operations time out after five
  minutes; interactive login allows ten minutes.

Integration and rollback instructions: `docs/codex-compatibility.md` in the GUI
repository. Report fork-specific issues there, not to the upstream maintainer.
