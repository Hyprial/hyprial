/** Hyprial compatibility transport: legacy global mode is isolated too. */
import { configureNetwork, disposeNetwork, networkFetch } from './network-rpc.ts'
export type OpenAICodexProxyMode = "off" | "scoped" | "global";

export interface ProxyPreferences {
  /** Whether this plugin leaves networking alone, proxies Codex only, or proxies the process. */
  proxyMode: OpenAICodexProxyMode;
  /** Explicit HTTP(S) proxy URL; empty uses standard proxy environment variables. */
  proxyUrl: string;
}

export const DEFAULT_PROXY_PREFERENCES: ProxyPreferences = {
  proxyMode: "scoped",
  proxyUrl: "",
};

function invalidProxyUrl(): Error {
  return new Error("Proxy URL must use http:// or https://");
}

/** Validate a persisted proxy value without echoing possible credentials. */
export function normalizeProxyUrl(value: string): string {
  const trimmed = value.trim();
  if (trimmed.length === 0) return "";
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    throw invalidProxyUrl();
  }
  if (
    (parsed.protocol !== "http:" && parsed.protocol !== "https:") ||
    parsed.hostname.length === 0
  ) {
    throw invalidProxyUrl();
  }
  return trimmed;
}


export class OpenAICodexProxyTransport {
  constructor(private readonly preferences: () => ProxyPreferences) {}
  async apply(): Promise<void> {
    const prefs = this.preferences()
    configureNetwork(prefs.proxyMode === 'off' ? 'off' : 'scoped', normalizeProxyUrl(prefs.proxyUrl))
  }
  readonly fetch: typeof fetch = async (input, init) => {
    await this.apply()
    return networkFetch(input, init)
  }
  async dispose(): Promise<void> { disposeNetwork() }
}
