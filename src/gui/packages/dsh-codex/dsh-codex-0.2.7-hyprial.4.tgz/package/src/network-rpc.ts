/** Hyprial IPC transport. Credentials travel only over the private child pipe. */
import { fork, type ChildProcess } from 'node:child_process'
import { existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

// The wire transports pi-ai's extensible payloads; validation belongs to each operation.
export type Wire = any
export type Callbacks = Record<string, (...args: Wire[]) => Wire>
let configuration = { mode: 'scoped', url: '' }
let current: NetworkWorker | undefined
const workers = new Set<NetworkWorker>()
export function configureNetwork(mode: string, url: string): void {
  if (configuration.mode === mode && configuration.url === url) return
  configuration = { mode, url }
  current?.retire()
  current = undefined
}
export function disposeNetwork(): void {
  for (const worker of workers) worker.close()
  current = undefined
}
export function childEnvironment(mode: string, url: string): NodeJS.ProcessEnv {
  const env = { ...process.env }
  const proxy = url || env.DSH_CODEX_PROXY || env.https_proxy || env.HTTPS_PROXY || env.http_proxy || env.HTTP_PROXY || env.all_proxy || env.ALL_PROXY || ''
  for (const name of Object.keys(env)) {
    if (/^(https?|all|no)_proxy$/i.test(name) || /^(NODE_OPTIONS|NODE_USE_ENV_PROXY|DSH_CODEX_PROXY)$/.test(name)) delete env[name]
  }
  if (mode !== 'off' && proxy) {
    try {
      if (!['http:', 'https:'].includes(new URL(proxy).protocol)) throw new Error()
    } catch { throw new Error('Codex proxy must use HTTP(S)') }
    env.HTTPS_PROXY = env.HTTP_PROXY = proxy
    env.NO_PROXY = 'localhost,127.0.0.1,::1'
  }
  return env
}

class NetworkWorker {
  child: ChildProcess
  pending = new Map<number, Wire>()
  sequence = 0
  retired = false
  constructor() {
    const sibling = new URL('./network-worker.js', import.meta.url)
    const workerPath = existsSync(sibling) ? sibling : new URL('../lib/network-worker.js', import.meta.url)
    this.child = fork(fileURLToPath(workerPath), [], {
      env: childEnvironment(configuration.mode, configuration.url),
      execArgv: [], serialization: 'advanced', stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
    })
    workers.add(this)
    this.child.on('message', (message: Wire) => this.receive(message))
    this.child.on('error', () => this.close())
    this.child.on('exit', () => this.close())
  }
  send(message: Wire): void {
    if (!this.child.connected) { this.close(); return }
    try { this.child.send(message, error => { if (error) this.close() }) }
    catch { this.close() }
  }
  receive(message: Wire): void {
    const job = this.pending.get(message.id)
    if (!job) return
    job.touch()
    if (message.kind === 'callback') {
      const controller = new AbortController()
      job.prompts.set(message.callbackId, controller)
      const args = message.args
      if (message.name === 'prompt') args[0] = { ...args[0], signal: controller.signal }
      Promise.resolve().then(() => job.callbacks[message.name]?.(...args)).then(
        value => this.send({ kind: 'callbackResult', id: message.id, callbackId: message.callbackId, value }),
        () => this.send({ kind: 'callbackResult', id: message.id, callbackId: message.callbackId, error: true }),
      ).finally(() => job.prompts.delete(message.callbackId))
    } else if (message.kind === 'cancelPrompt') {
      job.prompts.get(message.callbackId)?.abort()
    } else if (message.kind === 'data') {
      // One unacknowledged frame per operation provides IPC backpressure.
      job.deliver(message.value)
    } else {
      this.pending.delete(message.id)
      job.cleanup()
      if (message.kind === 'error') job.fail(new Error('Codex network operation failed in isolated worker'))
      else job.finish(message.value)
      if (!this.pending.size) {
        if (this.retired) this.close()
        else { this.child.unref(); this.child.channel?.unref() }
      }
    }
  }
  retire(): void { this.retired = true; if (!this.pending.size) this.close() }
  close(): void {
    workers.delete(this)
    if (current === this) current = undefined
    for (const job of this.pending.values()) { job.cleanup(); job.fail(new Error('Codex network worker stopped')) }
    this.pending.clear()
    if (this.child.connected) this.child.disconnect()
    this.child.kill()
  }
  call(operation: string, payload: Wire, signal?: AbortSignal, callbacks: Callbacks = {}) {
    const id = ++this.sequence
    this.child.ref(); this.child.channel?.ref()
    let queued: Wire[] = []
    let wake: (() => void) | undefined
    let ended = false
    let failure: Error | undefined
    let resolve!: (value: Wire) => void
    let reject!: (error: Error) => void
    const result = new Promise<Wire>((yes, no) => { resolve = yes; reject = no })
    void result.catch(() => {})
    const abort = () => {
      this.send({ kind: 'cancel', id })
      this.receive({ kind: 'error', id })
    }
    let timer: ReturnType<typeof setTimeout>
    const touch = () => { clearTimeout(timer); timer = setTimeout(abort, operation === 'login' ? 600_000 : 300_000); timer.unref() }
    touch()
    const prompts = new Map<number, AbortController>()
    this.pending.set(id, {
      callbacks, prompts, touch,
      cleanup: () => { clearTimeout(timer); signal?.removeEventListener('abort', abort); for (const p of prompts.values()) p.abort() },
      deliver: (value: Wire) => { queued.push(value); wake?.() },
      finish: (value: Wire) => { ended = true; resolve(value); wake?.() },
      fail: (error: Error) => { ended = true; failure = error; reject(error); wake?.() },
    })
    this.send({ kind: 'call', id, operation, payload, callbacks: Object.keys(callbacks) })
    signal?.addEventListener('abort', abort, { once: true })
    if (signal?.aborted) abort()
    const self = this
    return {
      result,
      cancel: abort,
      async *[Symbol.asyncIterator](): AsyncGenerator<Wire> {
        try {
          while (true) {
            if (queued.length) {
              const value = queued.shift()
              yield value
              self.send({ kind: 'ack', id })
            } else if (ended) {
              if (failure) throw failure
              return
            } else await new Promise<void>(r => { wake = r })
          }
        } finally { queued = []; if (!ended) abort() }
      },
    }
  }
}
export function networkCall(operation: string, payload: Wire, signal?: AbortSignal, callbacks?: Callbacks) {
  current ??= new NetworkWorker()
  return current.call(operation, payload, signal, callbacks)
}

/** Streaming HTTP for quota, native compaction, search and generated images. */
export const networkFetch: typeof fetch = async (input, init) => {
  const request = new Request(input, init)
  const call = networkCall('fetch', {
    url: request.url, method: request.method, headers: Object.fromEntries((request.headers as Wire).entries()),
    body: request.body ? new Uint8Array(await request.arrayBuffer()) : undefined,
  }, request.signal)
  const iterator = call[Symbol.asyncIterator]()
  const first = await iterator.next()
  if (first.done) throw new Error('Missing Codex response headers')
  const { status, statusText, headers } = first.value
  const body = new ReadableStream<Uint8Array>({
    async pull(controller) {
      try { const part = await iterator.next(); if (part.done) controller.close(); else controller.enqueue(part.value) }
      catch (error) { controller.error(error) }
    },
    async cancel() { call.cancel(); await iterator.return(undefined) },
  })
  if ([101, 204, 205, 304].includes(status) || request.method === 'HEAD') {
    await body.cancel()
    return new Response(null, { status, statusText, headers })
  }
  return new Response(body, { status, statusText, headers })
}
