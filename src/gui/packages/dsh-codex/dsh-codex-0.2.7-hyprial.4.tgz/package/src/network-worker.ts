/** Hyprial: the only process allowed to install the Codex proxy globally. */
import { EnvHttpProxyAgent, Agent, fetch as undiciFetch, WebSocket, setGlobalDispatcher } from 'undici'
import { openaiCodexProvider } from '@earendil-works/pi-ai/providers/openai-codex'
import type { Wire } from './network-rpc.ts'

const dispatcher = process.env.HTTPS_PROXY ? new EnvHttpProxyAgent() : new Agent()
setGlobalDispatcher(dispatcher)
// Use the same private undici dispatcher for Node WebSocket handshakes.
globalThis.WebSocket = class extends WebSocket {
  constructor(url: string | URL, protocols: Wire = []) {
    allowed(String(url).replace(/^wss:/, "https:"))
    super(url, Array.isArray(protocols) || typeof protocols === "string"
      ? { protocols, dispatcher } : { ...protocols, dispatcher })
  }
} as typeof globalThis.WebSocket
function allowed(raw: string): void {
  const url = new URL(raw)
  if (url.protocol !== 'https:' || url.port || url.username || url.password ||
      !((url.hostname === 'auth.openai.com' && (url.pathname.startsWith('/oauth/') || ['/api/accounts/deviceauth/usercode', '/api/accounts/deviceauth/token'].includes(url.pathname))) ||
        (url.hostname === 'chatgpt.com' && (url.pathname === '/backend-api' || url.pathname.startsWith('/backend-api/'))))) {
    throw new Error('Non-Codex network destination rejected')
  }
}
// Reject redirects instead of forwarding credentials to an unchecked destination.
globalThis.fetch = (async (input: Wire, init: Wire) => {
  allowed(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url)
  const response = await undiciFetch(input, { ...init, redirect: 'manual', dispatcher })
  if (response.status >= 300 && response.status < 400) {
    await response.body?.cancel()
    throw new Error('Codex redirect rejected')
  }
  return response
}) as typeof fetch
const provider = openaiCodexProvider()
const jobs = new Map<number, Wire>()
const send = (message: Wire) => new Promise<void>((resolve, reject) => {
  if (!process.connected) { reject(new Error('Host disconnected')); return }
  process.send!(message, (error: Error | null) => error ? reject(error) : resolve())
})
process.on('disconnect', () => process.exit(0))
process.on('message', async (message: Wire) => {
  const { id, kind } = message
  const existing = jobs.get(id)
  if (kind === 'ack') { existing?.ack?.(); return }
  if (kind === 'cancel') { existing?.controller.abort(); existing?.ack?.(); return }
  if (kind === 'callbackResult') {
    const callback = existing?.callbacks.get(message.callbackId)
    existing?.callbacks.delete(message.callbackId)
    if (message.error) callback?.reject(new Error('Interaction cancelled'))
    else callback?.resolve(message.value)
    return
  }
  if (kind !== 'call') return
  const controller = new AbortController()
  const job: Wire = { controller, callbacks: new Map(), sequence: 0 }
  jobs.set(id, job)
  const data = async (value: Wire) => {
    controller.signal.throwIfAborted()
    const acknowledged = new Promise<void>(resolve => { job.ack = resolve })
    await send({ kind: 'data', id, value })
    await acknowledged
    controller.signal.throwIfAborted()
  }
  const callback = async (name: string, args: Wire[], signal?: AbortSignal) => {
    const callbackId = ++job.sequence
    const result = new Promise<Wire>((resolve, reject) => job.callbacks.set(callbackId, { resolve, reject }))
    void result.catch(() => {})
    const cancel = () => {
      job.callbacks.get(callbackId)?.reject(new Error('Interaction cancelled'))
      job.callbacks.delete(callbackId)
      void send({ kind: 'cancelPrompt', id, callbackId }).catch(() => {})
    }
    signal?.addEventListener('abort', cancel, { once: true })
    controller.signal.addEventListener('abort', cancel, { once: true })
    try {
      await send({ kind: 'callback', id, callbackId, name, args })
      if (signal?.aborted || controller.signal.aborted) cancel()
      return await result
    } finally {
      signal?.removeEventListener('abort', cancel)
      controller.signal.removeEventListener('abort', cancel)
    }
  }
  try {
    const p = message.payload
    let result: Wire
    if (message.operation === 'login') {
      result = await provider.auth!.oauth!.login({
        signal: controller.signal,
        prompt: ({ signal, ...prompt }) => callback('prompt', [prompt], signal),
        notify: event => { void callback('notify', [event]).catch(() => {}) },
      })
    } else if (message.operation === 'refresh') {
      result = await provider.auth!.oauth!.refresh(p, controller.signal)
    } else if (message.operation === 'fetch') {
      const response = await fetch(p.url, { method: p.method, headers: p.headers, ...(p.body ? { body: p.body } : {}), signal: controller.signal })
      await data({ status: response.status, statusText: response.statusText, headers: Object.fromEntries((response.headers as Wire).entries()) })
      if (response.body) for await (const chunk of response.body as Wire) await data(chunk)
    } else if (message.operation === 'stream' || message.operation === 'streamSimple') {
      allowed(p.model.baseUrl)
      const options: Wire = { ...p.options, signal: controller.signal, env: { ...process.env }, fetch: globalThis.fetch }
      for (const name of message.callbacks) options[name] = (...args: Wire[]) => callback(name, args)
      const stream = provider[message.operation as 'stream' | 'streamSimple'](p.model, p.context, options)
      for await (const event of stream) await data(event)
    } else throw new Error('Unknown Codex network operation')
    await send({ kind: 'result', id, value: result })
  } catch {
    await send({ kind: 'error', id }).catch(() => {})
  } finally {
    controller.abort()
    jobs.delete(id)
  }
})
