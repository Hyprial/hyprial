/** Keep the DSH agent loop and credential locks in the host; isolate network I/O. */
import { openaiCodexProvider as upstreamProvider } from '@earendil-works/pi-ai/providers/openai-codex'
import { createAssistantMessageEventStream } from '@earendil-works/pi-ai'
import type { Provider, AssistantMessageEventStream } from '@earendil-works/pi-ai'
import { networkCall, type Wire, type Callbacks } from './network-rpc.ts'
export function openaiCodexProvider(): Provider {
  const provider = upstreamProvider()
  const stream = (operation: string, model: Wire, context: Wire, options: Wire = {}): AssistantMessageEventStream => {
    const { signal, fetch: _fetch, env: _env, onPayload, onResponse, ...serializable } = options
    const callbacks: Callbacks = {}
    if (onPayload) callbacks['onPayload'] = onPayload
    if (onResponse) callbacks['onResponse'] = onResponse
    const remote = networkCall(operation, { model, context, options: serializable }, signal, callbacks)
    const output = createAssistantMessageEventStream()
    let queuedBytes = 0
    let completed = false
    const sizes = new WeakMap<object, number>()
    const iterate = output[Symbol.asyncIterator].bind(output)
    output[Symbol.asyncIterator] = async function* () {
      try {
        for await (const event of { [Symbol.asyncIterator]: iterate }) {
          queuedBytes -= sizes.get(event) ?? 0
          yield event
        }
      } finally { if (!completed) remote.cancel() }
    }
    void (async () => {
      try {
        for await (const event of remote) {
          const bytes = Buffer.byteLength(JSON.stringify(event))
          queuedBytes += bytes
          if (queuedBytes > 64 * 1024 * 1024) throw new Error('Codex stream consumer exceeded 64 MiB buffer')
          sizes.set(event, bytes)
          if (event.type === 'done' || event.type === 'error') completed = true
          output.push(event)
        }
      } catch (error) {
        if (!completed) output.push({ type: 'error', reason: signal?.aborted ? 'aborted' : 'error', error: {
          role: 'assistant', content: [], api: model.api, provider: model.provider, model: model.id,
          timestamp: Date.now(), stopReason: signal?.aborted ? 'aborted' : 'error',
          errorMessage: error instanceof Error ? error.message : 'Codex isolated transport failed',
          usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0,
            cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } },
        } })
      } finally { completed = true; output.end() }
    })()
    return output
  }
  return {
    ...provider,
    auth: {
      ...provider.auth,
      oauth: {
        ...provider.auth!.oauth!,
        login: interaction => networkCall('login', null, interaction.signal, {
          prompt: prompt => interaction.prompt(prompt),
          notify: event => interaction.notify(event),
        }).result,
        refresh: (credential, signal) => networkCall('refresh', credential, signal).result,
      },
    },
    stream: (model, context, options) => stream('stream', model, context, options),
    streamSimple: (model, context, options) => stream('streamSimple', model, context, options),
  }
}
